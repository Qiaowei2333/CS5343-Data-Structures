package batch;

import java.util.*;
import java.io.*;
import command.*;
import exception.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**This Batch class maintains the N Commands that were parsed from the given batch file. */

public class Batch {
  public Map<String,Command> cmdLookup;
  public List<Command> commandList;
  
  /**
   * Construct the Batch.
   */
  
  public Batch(){
      cmdLookup = new HashMap<String,Command>();
      commandList = new ArrayList<Command>();
  }

  /**
   * Maintaince of the commands.
   */
  
  public void addCommand(Command command){
    if(command == null) System.out.println("command is null");
    if(commandList == null || commandList.isEmpty()) commandList = new ArrayList<Command>();
    commandList.add(command);
    if(this.cmdLookup == null || this.cmdLookup.isEmpty()) cmdLookup = new LinkedHashMap<String,Command>();
    cmdLookup.put(command.id, command);
  }
  
  /**
   * Different type of commands were mapped into different ID type for the convience of the later access.
   * Map was empoloyed for the FienameCommand, CmdCommand and PipeCommand for multiple fields. 
   */
  
  public Map<String,Command> getCommands() {
    if(this.cmdLookup == null || this.cmdLookup.isEmpty()) cmdLookup = new LinkedHashMap<String,Command>();
    return cmdLookup;
  }
}
