package command;

import java.util.*;
import java.io.*;
import batch.*;
import exception.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;


/**Command is an abstract class that defines three abstract methods: 
 *describe(): used to print a message to the console when the Command is executed. 
 *parse(): parse and extract the information contained in the given XML Element. 
 *execute() : execute the command. 
 */

public abstract class Command {
  public String id;
  public Command(String s) {};
  public Command() {};
  
  /**
   * parse the command
   * @param element
   * @throws ProcessException
   */
  public abstract void parse(Element element) throws ProcessException;
  
  /**
   * execute the command
   * @throws Exception
   */
  public abstract void execute() throws Exception;
  
  /**
   * describe the command
   * @return
   */
  public abstract String describe();
}
