package command;

import java.util.*;
import java.io.*;
import command.*;
import exception.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**The subclass of Command for CmdCommand. 
 *Handles CmdCommand type.
  */

public class ExecCommand extends Command{
  public String path;
  public String args;
  public String in;
  public String out;
  private String inFileName;
  private String outFileName;
  public ExecCommand(String name) {};
  
  /**
   * Maintain the CmdCommand type command.
   * @param elem the cmd element passed from BatchParser.
   */
  
  public void parse(Element element) throws ProcessException {
    this.id = element.getAttribute("id");
    if (id == null || id.isEmpty()) {
        throw new ProcessException("Missing ID in CMD Command");
    }
    
    this.path = element.getAttribute("path");
    if (path == null || path.isEmpty()) {
        throw new ProcessException("Missing PATH in CMD Command");
    }

    this.args = element.getAttribute("args");

    this.in = element.getAttribute("in");

    this.out = element.getAttribute("out");
  }
  

  public void execute() throws Exception {
    List<String> cmdArgs = new ArrayList<String>();
    if(!path.startsWith("java")) {
      cmdArgs.add(path);
    }
    else {
      cmdArgs.add("java");
    }
    if (!(args == null || args.isEmpty())) {
      StringTokenizer st = new StringTokenizer(args);
      while (st.hasMoreTokens()) {
          String tok = st.nextToken();
          cmdArgs.add(tok);
      }
    }
    
    ProcessBuilder builder = new ProcessBuilder();
    builder.command(cmdArgs);
    builder.directory(null);
    File wd = builder.directory();
    if(inFileName != null) {
      File inFile = new File(wd, inFileName);
      builder.redirectInput(inFile);
    }
    builder.redirectError(new File(wd, "error.txt"));
    if(outFileName != null) {
      File outFile  = new File(wd, outFileName);
      builder.redirectOutput(outFile);
    }
    Process process = builder.start();
    process.waitFor();
    System.out.println("Found " + this.path + " " + this.args + " command");
  }
 
 /**
  * allocate the path of filenamecommand to the execCommand
  * @param fc
  */
  
 public void setFilePath(FilenameCommand fc) {
    if(fc !=null && fc.id.equalsIgnoreCase(this.in)) this.inFileName = fc.path;
    if(fc != null && fc.id.equalsIgnoreCase(this.out)) this.outFileName = fc.path;
  }
 
  @Override
  public String describe() {
    // TODO Auto-generated method stub
    return "Executing exec " + id;
  }
}
