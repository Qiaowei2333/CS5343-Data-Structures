package command;

import java.util.*;
import java.io.*;
import command.*;
import exception.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**The subclass of Command for PipecmdExeCommand. 
 *Handles PipecmdExeCommand type.
  */

public class PipecmdExeCommand extends PipecmdCommand{
  public String path;
  public String args;
  public String in;
  public String out;
  public String inFileName;
  public String outFileName;
  public ProcessBuilder builder;
  
  /**
   * constructor
   * @param name
   */
  public PipecmdExeCommand(String name) {};
  
  
  public void parse(Element element){
    this.id = element.getAttribute("id");
    this.path = element.getAttribute("path");
    this.args = element.getAttribute("args");
    this.in = element.getAttribute("in") == null? null: element.getAttribute("in");
    this.out = element.getAttribute("out") == null? null : element.getAttribute("out");
  }
  
  public void execute() throws Exception {
    if(this.in == null && this.out == null) System.out.println("This is an invalid PipeExeCommand");
    List<String> cmdArgs = new ArrayList<String>();
    if(!path.startsWith("java")) {
      cmdArgs.add(path);
    }
    else {
      cmdArgs.add("java");
    }
    if (!(args == null || args.isEmpty())) {
      StringTokenizer st = new StringTokenizer(args);
      while (st.hasMoreTokens()) {
          String tok = st.nextToken();
          cmdArgs.add(tok);
      }
    }
    
    this.builder = new ProcessBuilder();
    builder.command(cmdArgs);
    builder.directory(null);
    File wd = builder.directory();
    if(inFileName != null) {
      File inFile = new File(wd, inFileName);
      builder.redirectInput(inFile);
    }
    builder.redirectError(new File(wd, "error.txt"));
    if(outFileName != null) {
      File outFile  = new File(wd, outFileName);
      builder.redirectOutput(outFile);
    }
  }
  
  /**
   * allocate the path of finenamecommand to the pipecmdexecommand
   * @param fc
   */
  
  public void setFilePath(FilenameCommand fc) {
    if(fc !=null && fc.id.equalsIgnoreCase(this.in)) this.inFileName = fc.path;
    if(fc != null && fc.id.equalsIgnoreCase(this.out)) this.outFileName = fc.path;
  }
  
  public String describe() {
    return "Executing exec " + id;
  }
}
