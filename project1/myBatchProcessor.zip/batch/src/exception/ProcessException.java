package exception;

import java.util.*;
import java.io.*;
import command.*;
import batch.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class ProcessException extends Exception{
  public ProcessException(String message) {
    super(message);
  }
  
  public ProcessException(String message, Throwable throwable) {
    super(message, throwable);
  }
}
